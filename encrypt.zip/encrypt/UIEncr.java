package encrypt;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;

import javax.swing.*;
public  class UIEncr extends JFrame implements ActionListener{ 
private static final long serialVersionUID = 1L;
public File file;
public String key,Ufile,addr;
public  JLabel statusLabel,actionLabel,emptyL1,emptyL2;
 JTextField secretKey;
 JButton choose,add,sub;
 UIEncr(){
	 super("CYB的加解密工具");
	  actionLabel = new JLabel("Action");
	  emptyL1     = new JLabel("                                       "
	  		+ "                                                        "
	  		+ "                             ");
	  emptyL2     = new JLabel("                                       "
		  		+ "                                                        "
		  		+ "                             ");
	  statusLabel = new JLabel("密钥：");
	  secretKey   = new JTextField(30);
	  choose      = new JButton("选择文件");
	  add         = new JButton("加密");
	  sub         = new JButton("解密");
	this.setLayout(new FlowLayout());
	this.setVisible(true);
	this.setResizable(false);
	this.setSize(400, 240);
	this.setLocation(550, 200);
	this.setDefaultCloseOperation(3);
	  choose.addActionListener(this);
	  add.addActionListener(this);
	  sub.addActionListener(this);
	  add(actionLabel);
	  add(emptyL1);
	  add(statusLabel);
	  add(secretKey);
	  add(emptyL2);
	  add(choose);
	  add(add);
	  add(sub);
 }
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         //new UIEncr();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("选择文件")) {
			chooseSendFile();
		}
		if (e.getActionCommand().equals("加密")) {
	         Ufile =null;
			try {
				alter();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        key=secretKey.getText().toString();
			//jiamiFile();
			jiamiFile jf = new jiamiFile();
	        Ufile=jf.encrypt(Ufile,key);
	       System.out.println("加密后：" + Ufile);
	        try {
				re_write();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        actionLabel.setText("加密成功！");
	        
		}
		if(e.getActionCommand().equals("解密")) {
			Ufile =null;
			try {
				alter();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        key=secretKey.getText().toString();
			//jiamiFile();
			jiemiFile jie =new jiemiFile();
			 Ufile=jie.decrypt(Ufile,key);
			 System.out.println("解密后：" + Ufile);
			 try {
					re_write();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		        actionLabel.setText("解密成功！");
		        
		}
	}

	

	private void chooseSendFile() {
		// TODO Auto-generated method stub
		addr=null;
		JFileChooser jfc=new JFileChooser();
	    jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
	    jfc.showDialog(new JLabel(),"选择文件");
	     file = jfc.getSelectedFile();
	    String A = jfc.getSelectedFile().getName();
	    addr = jfc.getSelectedFile().getAbsolutePath();
	    actionLabel.setText(A);
	}
    private String alter() throws IOException {
    	
        FileInputStream fis = new FileInputStream(file);
        InputStreamReader isr = new InputStreamReader(fis, "UTF-8"); 

         BufferedReader bf = new BufferedReader(isr);
         String content = "";
         StringBuilder sb = new StringBuilder();
         while (content != null) {
             content = bf.readLine();
             if (content == null) {
                 break;
             }
             sb.append(content.trim());
         }        bf.close();


         Ufile  = sb.toString();
         System.out.println(Ufile);
		 return Ufile;
    }
    
    private void re_write() throws IOException {
    	 File log = new File(addr);

    	    FileWriter fileWriter =new FileWriter(log);
    	    fileWriter.write("");
    	    fileWriter.flush();
    	    fileWriter.write(Ufile);//将字符串写入到指定的路径下的文件中
    	    fileWriter.close();
    	    
    }
    
	
	}
	