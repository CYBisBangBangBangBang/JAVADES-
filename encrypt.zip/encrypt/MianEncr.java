package encrypt;
public class MianEncr {
	private UIEncr UIEncr;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        UIEncr UI = new UIEncr();
        UI.main(args);
	}

}
