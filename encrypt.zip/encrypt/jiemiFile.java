package encrypt;
import java.io.BufferedReader;
import java.io.InputStreamReader;




public class jiemiFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public static String decrypt(String plainText, String key) {

		try {

			return new DES(key).decrypt(plainText);

		} catch (Exception e) {

			return null;

		}

	}
}
