package encrypt;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class jiamiFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			

	}
	public static String encrypt(String plainText, String key) {

		try {

			return new DES(key).encrypt(plainText);

		} catch (Exception e) {

			return null;

		}
		
	}
}
